#ifndef SPLITTER_H
#define SPLITTER_H

#include <QSplitter>
#include <QWidget>

class Splitter : public QSplitter
{
public:
    Splitter(Qt::Orientation, QWidget* = 0);
protected:
    QSplitterHandle *createHandle() override;
};

#endif // SPLITTER_H
