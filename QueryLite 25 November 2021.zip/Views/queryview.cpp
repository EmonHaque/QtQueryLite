#include "queryview.h"
#include "CustomWidget/codeditor.h"
#include <QToolBar>
#include <QAction>
#include <QIcon>
#include <QVBoxLayout>
#include <QStandardItem>
#include <QtDebug>
#include <QVector>
#include <QTextCursor>
#include <QTextDocument>
#include <QTextDocumentFragment>
#include <QFileDialog>
#include <QMessageBox>
#include <QLabel>
#include <QRegion>
#include <QPainterPath>
#include "global.h"
#include "querywidget.h"
#include "CustomWidget/actionbutton.h"

QueryView::QueryView(QWidget *parent) : RoundWidget(parent)
{
    setHeader("Query");
    editor = new CodeEditor(this);

    auto execute = new ActionButton(":/Icons/play.svg", "execute");
    auto comment = new ActionButton(":/Icons/comment.svg", "comment/uncomment");
    auto save = new ActionButton(":/Icons/save.svg", "save");
    addAction(execute);
    addAction(comment);
    addAction(save);
    addContent(editor);

    connect(execute, &ActionButton::triggered, this, &QueryView::emitQueryCallSignal);
    connect(editor, &CodeEditor::executionRequested, this, &QueryView::emitQueryCallSignal);
    connect(editor, &CodeEditor::commentRequested, this, &QueryView::commentUncomment);
    connect(comment, &ActionButton::triggered, this, &QueryView::commentUncomment);
    connect(save, &ActionButton::triggered, this, &QueryView::saveFile);
}

void QueryView::onDbChanged(QList<QString>& list)
{
    QVector<QString> itemsToRemove = {"Table", "View", "Index", "Trigger", "Column"};
    QList<QModelIndex> tobeRemoved;
    auto model = editor->getCompleterModel();

    for (int i = 0; i < model->rowCount(); i++) {
        auto index = model->index(i, 1);
        if(itemsToRemove.contains(model->data(index).toString()))
            tobeRemoved.append(index);
    }
    for (int i = tobeRemoved.count() - 1; i >= 0; i--)
        model->removeRow(tobeRemoved[i].row());

    foreach(QString name, list){
        auto splits = name.split(',');
        QStandardItem *col1, *col2;

        if(splits[0] == "table"){
            col1 = new QStandardItem(QIcon(":/Icons/table.svg"), splits[1]);
            col2 = new QStandardItem("Table");
        }
        else if(splits[0] == "view"){
            col1 = new QStandardItem(QIcon(":/Icons/view.svg"), splits[1]);
            col2 = new QStandardItem("View");
        }
        else if(splits[0] == "index"){
            col1 = new QStandardItem(QIcon(":/Icons/index.svg"), splits[1]);
            col2 = new QStandardItem("Index");
        }
        else if(splits[0] == "trigger"){
            col1 = new QStandardItem(QIcon(":/Icons/trigger.svg"), splits[1]);
            col2 = new QStandardItem("Trigger");
        }
        else if(splits[0] == "column"){
            col1 = new QStandardItem(QIcon(":/Icons/column.svg"), splits[1]);
            col2 = new QStandardItem("Column");
        }
        col1->setFont(QFont(col2->font().family(), -1, QFont::Bold, false));
        col2->setFont(QFont(col2->font().family(), -1, -1,true));
        col2->setForeground(QBrush(Qt::gray));
        col2->setTextAlignment(Qt::AlignVCenter | Qt::AlignRight);
        model->appendRow(QList<QStandardItem *>() << col1 << col2);
    }
    editor->getHighlighter()->setObjectRules(list);
}


void QueryView::emitQueryCallSignal()
{
    emit queryCall(editor->textCursor().hasSelection() ?
                       editor->textCursor().selection().toPlainText() :
                       editor->toPlainText());
}

void QueryView::commentUncomment()
{
    auto cursor = editor->textCursor();
    if(!cursor.hasSelection()) return;

    auto text = cursor.selectedText();
    int start = cursor.selectionStart();
    int end = cursor.selectionEnd();
    cursor.setPosition(start);
    int startLine = cursor.blockNumber();
    cursor.setPosition(end);
    int endLine = cursor.blockNumber();
    int numberOfLines = endLine - startLine + 1;
    cursor.setPosition(start);

    if(text.contains("--")){
        if(numberOfLines > 1){
            int newEnd = end;
            for(int i = 0; i < numberOfLines; ++i){
                while (cursor.position() < newEnd) {
                    cursor.movePosition(QTextCursor::NextWord, QTextCursor::KeepAnchor);
                    if(cursor.selectedText().contains("--")){
                        cursor.insertText(cursor.selectedText().replace("--", ""));
                        newEnd -= 2;
                    }
                }
                cursor.movePosition(QTextCursor::NextBlock);
            }
            cursor.setPosition(start, QTextCursor::MoveAnchor);
            cursor.setPosition(newEnd, QTextCursor::KeepAnchor);
        }
        else{
            int count = 0;
            int newEnd = end;
            while (cursor.position() < newEnd) {
                cursor.movePosition(QTextCursor::NextWord, QTextCursor::KeepAnchor);
                if(cursor.selectedText().contains("--")){
                    cursor.insertText(cursor.selectedText().replace("--", ""));
                    count += 2;
                    newEnd -= 2;
                }
            }
            cursor.setPosition(start, QTextCursor::MoveAnchor);
            cursor.setPosition(end - count, QTextCursor::KeepAnchor);
        }
    }
    else{
        if(numberOfLines > 1){
            for(int i = 0; i < numberOfLines; ++i){
                cursor.insertText("--");
                if(cursor.blockNumber() < endLine)
                    cursor.movePosition(QTextCursor::NextBlock);
            }
            cursor.movePosition(QTextCursor::Up, QTextCursor::MoveAnchor, numberOfLines - 1);
            cursor.setPosition(start, QTextCursor::MoveAnchor);
            cursor.setPosition(end + numberOfLines * 2, QTextCursor::KeepAnchor);

        }
        else{
            cursor.insertText("--");
            cursor.movePosition(QTextCursor::Left, QTextCursor::MoveAnchor, 2);
            cursor.movePosition(QTextCursor::Right, QTextCursor::KeepAnchor, text.length() + 2);
        }
    }
    editor->setTextCursor(cursor);
}

void QueryView::saveFile()
{
    QString fileName = QFileDialog::getSaveFileName(this, "Save Query", "", "SQL File (*.sql)");
    if (fileName.isEmpty()) return;
    else {
        QFile file(fileName);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::information(this, "Unable to open file", file.errorString());
            return;
        }
        QTextStream out(&file);
        out << editor->toPlainText();
    }
}


