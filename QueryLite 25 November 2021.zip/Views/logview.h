#ifndef LOGVIEW_H
#define LOGVIEW_H

#include <QObject>
#include <QPlainTextEdit>
#include <QSqlError>
#include "CustomWidget/roundwidget.h"

class LogView : public RoundWidget
{
    Q_OBJECT
public:
    explicit LogView(QWidget *parent = nullptr);

public slots:
    void onMessageReceived(const QString& msg);
private slots:
    void clearMessages();

private:
    QPlainTextEdit *box;

};

#endif // LOGVIEW_H
