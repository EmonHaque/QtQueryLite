#ifndef GLOBAL_H
#define GLOBAL_H
#include <QSqlDatabase>
#include <QMap>
#include <QSqlQuery>
#include <QStringList>

extern QSqlDatabase db;
extern bool isConnected;
extern QSqlQuery sqlQuery;
extern QMap<QString, QStringList*> fileContent;

#endif // GLOBAL_H
