#include "tableheader.h"
#include <QScrollBar>
#include <QEvent>
#include <QKeyEvent>
#include <QPainter>

TableHeader::TableHeader(QTableView * parent) : QHeaderView(Qt::Horizontal, parent)
{
    setDefaultAlignment(Qt::AlignTop | Qt::AlignHCenter);
    setStretchLastSection(true);
    connect(this, &TableHeader::sectionResized, this, &TableHeader::updateGeometries);
    connect(parent->horizontalScrollBar(), &QScrollBar::valueChanged, this, &TableHeader::updatePosition);
}
TableHeader::~TableHeader() { }
void TableHeader::paintSection(QPainter * painter, const QRect & rect, int logicalIndex) const{
    painter->fillRect(rect, Qt::transparent);
    painter->drawText(rect, Qt::AlignLeft, model()->headerData(logicalIndex, Qt::Horizontal, Qt::DisplayRole).toString());
}
QSize TableHeader::sizeHint() const
{
    int width = 0;
    int height = 0;
    for (int i = 0; i < count(); i++){
        width += sectionSize(i);
        auto size = sectionSizeFromContents(i);
        width += size.width();
        height = size.height();
    }
    return QSize(width, height * 2);
}
QList<QString>& TableHeader::getQueries() { return queries; }
void TableHeader::resetBoxes(int count){
    queries.clear();
    if(count == lineEdits.size()) {
        for (int i = 0; i < lineEdits.size(); i++) {
            lineEdits[i]->setText("");
            queries.append("");
        }
        return;
    }
    int diff = count - lineEdits.size();
    if(diff > 0){
        for (int i = 0; i < diff; i++) {
            auto edit = new QLineEdit(this);
            edit->installEventFilter(this);
            lineEdits.append(edit);
            connect(edit, &QLineEdit::textChanged, this, &TableHeader::textChanged);
            edit->show();
        }
    }
    else{
        diff = abs(diff);
        for (int i = 0; i < diff; i++) {
            auto line = lineEdits.takeLast();
            delete line;
        }
    }
    for (int i = 0; i < lineEdits.size(); i++) {
        lineEdits[i]->setText("");
        queries.append("");
    }
}
bool TableHeader::eventFilter(QObject *o, QEvent *e){
    for (int i = 0; i < lineEdits.size(); i++) {
        if(lineEdits[i] != o) continue;
        if(e->type() != QEvent::KeyPress) return false;
        auto event = static_cast<QKeyEvent*>(e);
        if(event->key() != Qt::Key_Tab) return false;
        if(i + 1 == lineEdits.size()) lineEdits[0]->setFocus(Qt::FocusReason::OtherFocusReason);
        else lineEdits[i + 1]->setFocus(Qt::FocusReason::OtherFocusReason);
        return true;
    }
    return QHeaderView::eventFilter(o, e);
}
void TableHeader::updateGeometries()
{
    for (int i = 0; i < count(); i++) {
        auto edit = lineEdits.at(i);
        edit->setGeometry(sectionViewportPosition(i), height() / 2, sectionSize(i), height() / 2);
    }
}
void TableHeader::updatePosition()
{
    int height = QHeaderView::sizeHint().height();
    for (int i = 0; i < count(); i++){
        auto edit = lineEdits.at(i);
        edit->move(sectionPosition(i) - offset(), height);
    }
}
void TableHeader::textChanged(){
    queries.clear();
    for (int i = 0; i < count(); i++){
        auto edit = lineEdits.at(i);
        queries.append(edit->text());
    }
    emit queryChanged();
}
