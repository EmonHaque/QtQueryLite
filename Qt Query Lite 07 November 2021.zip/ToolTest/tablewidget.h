#ifndef TABLEWIDGET_H
#define TABLEWIDGET_H

#include <QStandardItemModel>
#include <QSqlTableModel>
#include <QTableView>
#include <QLabel>
#include "CustomWidget/roundwidget.h"

class TableHeader;

class TableWidget : public QWidget
{
    Q_OBJECT
public:
    explicit TableWidget(QWidget *parent = nullptr);
public slots:
    void onDbChanged(QList<QString>& list);
    void onComboSelectionChanged(int index);
    void onNoSelect(const QString& query);
private slots:
    void refreshModel();
private:
    void queryDatabase();
    QStandardItemModel * comboModel;
    QSqlTableModel * tableModel;
    QTableView * table;
    TableHeader * tableHeader;
    //TableProxyModel * tableProxy;
    QLabel * countLabel;
    QString tableName, filterExpression;
    bool wasLastDML;
    RoundWidget * roundWidget;
};

#endif // TABLEWIDGET_H
