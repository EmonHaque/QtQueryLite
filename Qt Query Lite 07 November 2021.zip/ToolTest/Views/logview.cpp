#include "logview.h"
#include <QVBoxLayout>
#include <QDateTime>
#include <QTextCursor>
#include <QToolBar>
#include <QLabel>
#include "CustomWidget/actionbutton.h"

LogView::LogView(QWidget *parent) : RoundWidget(parent)
{
    setHeader("Log");
    box = new QPlainTextEdit(this);
    box->setFrameStyle(QFrame::NoFrame);
    auto p = box->palette();
    p.setColor(QPalette::Base, palette().color(QPalette::Window));
    box->setPalette(p);

    box->setReadOnly(true);
    auto clear = new ActionButton(":/Icons/clear.svg", "clear log");
    connect(clear, &ActionButton::triggered, this, &LogView::clearMessages);
    addAction(clear);
    addContent(box);
}

void LogView::onMessageReceived(const QString &msg)
{
    auto cursor = box->textCursor();
    cursor.movePosition(QTextCursor::Start);
    auto time = QDateTime::currentDateTime().toString("hh:mm:ss AP");
    QString log(time + " : " + msg.right(msg.length() - 2));
    QTextCharFormat format;
    format.setForeground(msg.startsWith('e') ? QBrush(Qt::red) : QBrush(Qt::darkGreen));
    cursor.insertText(log + '\n', format);
}

void LogView::clearMessages()
{
    box->document()->clear();
}
