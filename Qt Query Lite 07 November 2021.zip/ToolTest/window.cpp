#include "window.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QDir>
#include <QStringList>
#include <QIcon>
#include <QMouseEvent>
#include <QPainterPath>
#include <QSizeGrip>
#include <QPainter>
#include "querywidget.h"
#include "tablewidget.h"
#include "CustomWidget/actionbutton.h"
#include "CustomWidget/splitter.h"
#include "global.h"

QMap<QString, QStringList*> fileContent;

Window::Window(QWidget *parent) : QWidget(parent), radius(10)
{
    QDir directory(":/Files/");
    QStringList files = directory.entryList(QStringList() << "*.txt",QDir::Files);
    foreach(QString fileName, files) {
        auto list = new QStringList;
        QFile file(":/Files/" + fileName);
        file.open(QIODevice::ReadOnly | QIODevice::Text);
        QTextStream in(&file);
        QString line = in.readLine();
        while (!line.isNull()) {
            list->append(line);
            line = in.readLine();
        }
        file.close();
        auto name = fileName.replace(".txt", "").replace("func", "Function ");
        fileContent.insert(name, list);
    }
    setWindowFlags(Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint);
    setAttribute(Qt::WA_TranslucentBackground);
    setWindowTitle("Query Lite");
    setWindowIcon(QIcon(":/Icons/appicon.ico"));
    auto grid = new QGridLayout(this);
    grid->setContentsMargins(0,0,0,0);
    stack = new QStackedWidget(this);
    stack->setSizePolicy(QSizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding));
    auto queryWidget = new QueryWidget();
    auto tableWidget = new TableWidget();

    qDeleteAll(fileContent);

    stack->addWidget(queryWidget);
    stack->addWidget(tableWidget);

    leftBar = new QVBoxLayout;
    leftBar->setContentsMargins(5,0,0,10);
    auto vSpacer = new QWidget(this);
    vSpacer->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Expanding);
    auto a1 = new ActionButton(":/Icons/queryview.svg", "query", 20);
    auto a2 = new ActionButton(":/Icons/tableview.svg", "table", 20);
    leftBar->addWidget(vSpacer);
    leftBar->addWidget(a1);
    leftBar->addWidget(a2);

    connect(a1, &ActionButton::triggered, this, &Window::resetCentralWidget);
    connect(a2, &ActionButton::triggered, this, &Window::resetCentralWidget);
    a1->setIsChecked(true);

    auto topBar = new QHBoxLayout;
    topBar->setContentsMargins(0,5,10,0);
    auto hSpacer = new QWidget(this);
    hSpacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Maximum);
    auto minimize = new ActionButton(":/Icons/minimize.svg", "minimize");
    maximize = new ActionButton(":/Icons/maximize.svg", "maximize");
    auto close = new ActionButton(":/Icons/close.svg", "close");

    connect(close, &ActionButton::triggered, [=]{this->close();});
    connect(minimize, &ActionButton::triggered, [=]{this->showMinimized();});
    connect(maximize, &ActionButton::triggered, this, &Window::maximizeRestore);

    connect(queryWidget, &QueryWidget::dbChanged, tableWidget, &TableWidget::onDbChanged);
    connect(queryWidget, &QueryWidget::noSelect, tableWidget, &TableWidget::onNoSelect);

    topBar->addWidget(hSpacer);
    topBar->addWidget(minimize);
    topBar->addWidget(maximize);
    topBar->addWidget(close);

    grid->addLayout(topBar, 0, 1);
    grid->addLayout(leftBar,1, 0);
    grid->addWidget(stack, 1, 1);
    grid->setColumnStretch(0, 0);
    grid->setRowStretch(0, 0);
    setLayout(grid);

    auto sizeGrip = new QSizeGrip(this);
    grid->addWidget(sizeGrip, 1,1,1,1,Qt::AlignBottom | Qt::AlignRight);
}
void Window::mouseMoveEvent(QMouseEvent *event){
    if (event->buttons() & Qt::LeftButton) {
        move(event->globalPosition().toPoint() - dragPosition);
        event->accept();
    }
}
void Window::mousePressEvent(QMouseEvent *event){
    if (event->button() == Qt::LeftButton) {
        dragPosition = event->globalPosition().toPoint() - frameGeometry().topLeft();
        event->accept();
    }
}
void Window::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    QPainterPath path;
    path.addRoundedRect(contentsRect(), 10,10);
    painter.fillPath(path, palette().color(QPalette::Window));

    auto f = painter.font();
    f.setBold(true);
    f.setPointSize(12);
    painter.setFont(f);
    painter.setPen(Qt::gray);
    painter.translate(leftBar->contentsRect().width(), height() - 60);
    painter.rotate(-90);
    painter.drawText(QPoint(0,0), "Query Lite");
}
void Window::maximizeRestore(){
    if(isMaximized()) {
        showNormal();
        maximize->setIcon(":/Icons/maximize.svg");
        maximize->setToolTip("maximize");
    }
    else {
        showMaximized();
        maximize->setIcon(":/Icons/restore.svg");
        maximize->setToolTip("restore");
    }
}
void Window::resetCentralWidget(){
    auto action = (ActionButton*)sender();
    auto leftbar = static_cast<QVBoxLayout*>(action->parent());
    foreach(auto widget, leftbar->children()){
        auto tool = qobject_cast<ActionButton*>(widget);
        if(tool && tool != action) tool->setIsChecked(false);
    }
    action->setIsChecked(true);
    if(action->toolTip() == "query"){
        stack->setCurrentIndex(0);
    }
    else if(action->toolTip() == "table") {
        stack->setCurrentIndex(1);
    }
}
