#pragma once
#include <QWidget>
#include "CustomWidget/codeditor.h"


class LineNumberArea : public QWidget
{
public:
    explicit LineNumberArea(CodeEditor * editor);
    QSize sizeHint() const override;
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    CodeEditor *codeEditor;
};

