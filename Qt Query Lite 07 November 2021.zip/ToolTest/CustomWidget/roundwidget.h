#ifndef ROUNDWIDGET_H
#define ROUNDWIDGET_H

#include <QObject>
#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>

class RoundWidget : public QWidget
{
    Q_OBJECT
public:
    explicit RoundWidget(QWidget *parent = nullptr);
    void addAction(QWidget*, bool = false);
    void addContent(QWidget*);
    void setHeader(const QString&);
protected:
    void paintEvent(QPaintEvent*) override;
private:
    QHBoxLayout * toolbar;
    QVBoxLayout * layout;
    QLabel * header;
    QWidget * spacer;
};

#endif // ROUNDWIDGET_H
