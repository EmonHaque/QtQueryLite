#ifndef HIGHLIGHTER_H
#define HIGHLIGHTER_H

#include <QSyntaxHighlighter>
#include <QRegularExpression>
#include <QObject>
#include <QFile>
#include <QTextStream>

class Highlighter : public QSyntaxHighlighter
{
    Q_OBJECT
public:
    explicit Highlighter(QTextDocument *parent = nullptr);
    void setObjectRules(QList<QString>& list);
protected:
    void highlightBlock(const QString &text) override;

private:
    struct HighlightingRule
    {
        QRegularExpression pattern;
        QTextCharFormat format;
    };
    QVector<HighlightingRule> highlightingRules;
    QTextCharFormat dataTypeFormat;
    QTextCharFormat keywordFormat;
    QTextCharFormat objectFormat;
    QTextCharFormat commentFormat;
    QTextCharFormat quotationFormat1;
    QTextCharFormat quotationFormat2;
    QTextCharFormat functionFormat;
    void addQuoteAndCommentFormat();
};

#endif // HIGHLIGHTER_H
