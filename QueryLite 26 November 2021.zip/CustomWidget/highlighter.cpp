#include "CustomWidget/highlighter.h"
#include "global.h"

Highlighter::Highlighter(QTextDocument *parent) : QSyntaxHighlighter(parent)
{
    HighlightingRule rule;

    objectFormat.setForeground(Qt::darkGray);
    objectFormat.setFontItalic(true);

    keywordFormat.setForeground(Qt::darkBlue);
    keywordFormat.setFontWeight(QFont::Bold);

    functionFormat.setFontItalic(true);
    functionFormat.setForeground(Qt::blue);

    dataTypeFormat.setFontWeight(QFont::Bold);
    dataTypeFormat.setForeground(Qt::blue);

    foreach(auto key, fileContent.keys()){
        auto lines = *(fileContent.value(key));
        if(key == "Keyword"){
            foreach(auto line, lines){
                auto lower = line.toLower();
                rule.pattern = QRegularExpression("\\b" + lower + "\\b");
                rule.format = keywordFormat;
                highlightingRules.append(rule);
                rule.pattern = QRegularExpression("\\b" + line + "\\b");
                rule.format = keywordFormat;
                highlightingRules.append(rule);
            }
        }
        else if(key.contains("Function")){
            foreach(auto line, lines){
                auto trimmed = line.left(line.indexOf('('));
                rule.pattern = QRegularExpression("\\b" + trimmed + "\\b");
                rule.format = functionFormat;
                highlightingRules.append(rule);
            }
        }
        else if(key == "dataType") {
            foreach(auto line, lines){
                auto lower = line.toLower();
                rule.pattern = QRegularExpression("\\b" + lower + "\\b");
                rule.format = dataTypeFormat;
                highlightingRules.append(rule);
                rule.pattern = QRegularExpression("\\b" + line + "\\b");
                rule.format = dataTypeFormat;
                highlightingRules.append(rule);
            }
        }
    }
    addQuoteAndCommentFormat();
}

void Highlighter::setObjectRules(QList<QString> &list)
{
    QVector<int> toBeRemoved;
    for (int i = 0; i < highlightingRules.size(); i++) {
        if(highlightingRules[i].format == objectFormat ||
           highlightingRules[i].format == quotationFormat1 ||
           highlightingRules[i].format == quotationFormat2 ||
           highlightingRules[i].format == commentFormat)
            toBeRemoved.append(i);
    }
    for (int i = toBeRemoved.size(); i > 0; i--)
        highlightingRules.removeAt(toBeRemoved[i - 1]);

    HighlightingRule rule;
    foreach(auto object, list){
        auto splits = object.split(',');
        rule.pattern = QRegularExpression("\\b" + splits[1] + "\\b");
        rule.format = objectFormat;
        highlightingRules.append(rule);
    }
    addQuoteAndCommentFormat();
}

void Highlighter::addQuoteAndCommentFormat(){
    HighlightingRule rule;
    quotationFormat1.setForeground(Qt::darkGreen);
    rule.pattern = QRegularExpression(QStringLiteral("(?:\")([^\"]+)(?:\")"));
    rule.format = quotationFormat1;
    highlightingRules.append(rule);

    quotationFormat2.setForeground(Qt::darkGreen);
    rule.pattern = QRegularExpression(QStringLiteral("(?:')([^']+)(?:')"));
    rule.format = quotationFormat2;
    highlightingRules.append(rule);

    commentFormat.setForeground(Qt::darkGreen);
    rule.pattern = QRegularExpression("--[^\n]*");
    rule.format = commentFormat;
    highlightingRules.append(rule);
}

void Highlighter::highlightBlock(const QString &text)
{
    for (const HighlightingRule &rule : qAsConst(highlightingRules)) {
        QRegularExpressionMatchIterator matchIterator = rule.pattern.globalMatch(text);
        while (matchIterator.hasNext()) {
            QRegularExpressionMatch match = matchIterator.next();
            setFormat(match.capturedStart(), match.capturedLength(), rule.format);
        }
    }
    //    setCurrentBlockState(0);
    //    int startIndex = 0;
    //    if (previousBlockState() != 1)
    //        startIndex = text.indexOf(commentStartExpression);

    //    while (startIndex >= 0) {
    //        QRegularExpressionMatch match = commentEndExpression.match(text, startIndex);
    //        int endIndex = match.capturedStart();
    //        int commentLength = 0;
    //        if (endIndex == -1) {
    //            setCurrentBlockState(1);
    //            commentLength = text.length() - startIndex;
    //        } else {
    //            commentLength = endIndex - startIndex
    //                    + match.capturedLength();
    //        }
    //        setFormat(startIndex, commentLength, multiLineCommentFormat);
    //        startIndex = text.indexOf(commentStartExpression, startIndex + commentLength);
    //    }
}
