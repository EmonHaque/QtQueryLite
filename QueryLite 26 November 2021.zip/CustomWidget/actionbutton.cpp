#include "actionbutton.h"
#include <QDebug>
#include <QFile>
#include <QSvgRenderer>
#include <QMouseEvent>

ActionButton::ActionButton(const QString &fileName, const QString toolTip, int size, QWidget *parent)
    : QSvgWidget(parent)
{
    QFile f(fileName);
    f.open(QIODevice::ReadOnly | QIODevice::Text);
    m_document.setContent(f.readAll());  
    setToolTip(toolTip);
    m_isChecked = false;
    if(size == 0) {
        setFixedSize(QSize(16,16));
    }
    else setFixedSize(QSize(size, size));
    changeColor(QColor(Qt::black));
    f.close();
}
bool ActionButton::isChecked(){ return m_isChecked; }
void ActionButton::setIsChecked(bool value){
    if(m_isChecked == value) return;
    m_isChecked = value;
    if(value) changeColor(Qt::blue);
    else changeColor(Qt::black);;
}

void ActionButton::setIcon(const QString & fileName)
{
    QFile f(fileName);
    f.open(QIODevice::ReadOnly | QIODevice::Text);
    m_document.setContent(f.readAll());
    changeColor(Qt::black);
}

void ActionButton::enterEvent(QEnterEvent*){
    if(!m_isChecked && isEnabled()) changeColor(Qt::blue);
}
void ActionButton::leaveEvent(QEvent*){
    if(!m_isChecked && isEnabled()) changeColor(Qt::black);
}
void ActionButton::mousePressEvent(QMouseEvent *){
    if(!m_isChecked && isEnabled()) changeColor(Qt::red);
}
void ActionButton::mouseReleaseEvent(QMouseEvent* e){
    if(!m_isChecked && isEnabled() && rect().contains(e->pos())) emit triggered();
}
void ActionButton::changeEvent(QEvent *e){
    if(e->type() != QEvent::EnabledChange) return;
    if(isEnabled()) changeColor(QColor(Qt::black));
    else changeColor(QColor(Qt::lightGray));
}
void ActionButton::changeColor(const QColor &color){
    m_document.elementsByTagName("path").at(0).toElement().setAttribute("fill", color.name());
    renderer()->load(m_document.toByteArray());
}

