#include "roundwidget.h"
#include <QPainterPath>
#include <QFrame>
#include <QPainter>
#include <QBitmap>
#include <QGraphicsDropShadowEffect>

RoundWidget::RoundWidget(QWidget *parent) : QWidget(parent){
    layout = new QVBoxLayout(this);
    toolbar = new QHBoxLayout;
    layout->addLayout(toolbar);
    header = new QLabel(this);
    header->setFont(QFont(header->font().family(), -1, QFont::Bold, false));
    spacer = new QWidget(this);
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    toolbar->addWidget(header);
    toolbar->addWidget(spacer);
    auto separator = new QFrame;
    separator->setFrameShape(QFrame::HLine);
    separator->setFrameShadow(QFrame::Sunken);
    layout->addWidget(separator);
    setContentsMargins(0,2,2,2);
}
void RoundWidget::addAction(QWidget * action, bool removeSpacer) {
    if(spacer && removeSpacer) {
        toolbar->removeWidget(spacer);
        delete spacer;
    }
    toolbar->addWidget(action);
}
void RoundWidget::addContent(QWidget * content) { layout->addWidget(content); }
void RoundWidget::setHeader(const QString & text) { header->setText(text); }
void RoundWidget::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    QPainterPath path;
    path.addRoundedRect(contentsRect(), 10,10);
    painter.fillPath(path, palette().color(QPalette::Window));

}
