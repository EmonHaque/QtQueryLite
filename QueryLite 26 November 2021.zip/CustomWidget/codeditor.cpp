#include "CustomWidget/codeditor.h"
#include "CustomWidget/linenumberarea.h"
#include <QTableView>
#include <QHeaderView>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QMenu>
#include <QMap>
#include <QStringList>
#include "global.h"

CodeEditor::CodeEditor(QWidget * parent) : QPlainTextEdit(parent)
{
    setFrameStyle(QFrame::NoFrame);
    setLineWrapMode(QPlainTextEdit::NoWrap);
    lineNumberArea = new LineNumberArea(this);
    completer = new QCompleter(this);
    completer->setWidget(this);
    completerModel = getModel();
    completer->setCaseSensitivity(Qt::CaseInsensitive);
    completer->setModel(completerModel);

    connect(this, &CodeEditor::blockCountChanged, this, &CodeEditor::updateLineNumberAreaWidth);
    connect(this, &CodeEditor::updateRequest, this, &CodeEditor::updateLineNumberArea);
    connect(this, &CodeEditor::cursorPositionChanged, this, &CodeEditor::highlightCurrentLine);

    updateLineNumberAreaWidth(0);
    highlightCurrentLine();
    highlighter = new Highlighter(this->document());
    QObject::connect(completer, QOverload<const QString &>::of(&QCompleter::activated),
                     this, &CodeEditor::insertCompletion);
    setAcceptDrops(true);

}

QStandardItemModel *CodeEditor::getCompleterModel()
{
    return completerModel;
}

Highlighter *CodeEditor::getHighlighter()
{
    return highlighter;
}

void CodeEditor::lineNumberAreaPaintEvent(QPaintEvent *event)
{
    QPainter painter(lineNumberArea);
    painter.fillRect(event->rect(), Qt::lightGray);
    QTextBlock block = firstVisibleBlock();
    int blockNumber = block.blockNumber();
    int top = qRound(blockBoundingGeometry(block).translated(contentOffset()).top());
    int bottom = top + qRound(blockBoundingRect(block).height());
    while (block.isValid() && top <= event->rect().bottom()) {
        if (block.isVisible() && bottom >= event->rect().top()) {
            QString number = QString::number(blockNumber + 1);
            painter.setPen(Qt::black);
            painter.drawText(0, top, lineNumberArea->width(), fontMetrics().height(),
                             Qt::AlignRight, number + "."); // last . is added
        }
        block = block.next();
        top = bottom;
        bottom = top + qRound(blockBoundingRect(block).height());
        ++blockNumber;
    }
}

int CodeEditor::lineNumberAreaWidth()
{
    int digits = 1;
    int max = qMax(1, blockCount());
    while (max >= 10) {
        max /= 10;
        ++digits;
    }
    int space = 3 + fontMetrics().horizontalAdvance(QLatin1Char('9')) * digits + 5; // last +5 is added
    return space;
}

void CodeEditor::wheelEvent(QWheelEvent *e)
{
    if(e->modifiers().testFlag(Qt::ControlModifier)) {
        if(e->angleDelta().y() > 0) zoomIn();
        else zoomOut();
        QRect cr = contentsRect();
        lineNumberArea->setGeometry(QRect(cr.left(), cr.top(), lineNumberAreaWidth(), cr.height()));
    }
    else QPlainTextEdit::wheelEvent(e);
}

void CodeEditor::dragEnterEvent(QDragEnterEvent *event)
{ 
    if(event->mimeData()->text().contains('\n')){
        event->ignore();
        return;
    }
    event->acceptProposedAction();
}
void CodeEditor::dropEvent(QDropEvent *event)
{
    event->acceptProposedAction();
    QFile file (event->mimeData()->text().remove("file:///"));
    file.open(QIODevice::ReadOnly);
    QTextStream in(&file);
    insertPlainText(in.readAll());
    file.close();
}

void CodeEditor::keyPressEvent(QKeyEvent *e)
{
    if(e->key() == Qt::Key_F5){
        emit executionRequested();
        return;
    }
    else if(e->key() == Qt::Key_K && e->modifiers() == Qt::ControlModifier){
        emit commentRequested();
        return;
    }
    if (completer && completer->popup()->isVisible()) {
        // The following keys are forwarded by the completer to the widget
        switch (e->key()) {
        case Qt::Key_Enter:
        case Qt::Key_Return:
        case Qt::Key_Escape:
        case Qt::Key_Tab:
        case Qt::Key_Backtab:
            e->ignore();
            return; // let the completer do default behavior
        default:
            break;
        }
    }

    const bool isShortcut = (e->modifiers().testFlag(Qt::ControlModifier) && e->key() == Qt::Key_E); // CTRL+E
    if (!completer || !isShortcut) // do not process the shortcut when we have a completer
        QPlainTextEdit::keyPressEvent(e);
    const bool ctrlOrShift = e->modifiers().testFlag(Qt::ControlModifier) ||
            e->modifiers().testFlag(Qt::ShiftModifier);
    if (!completer || (ctrlOrShift && e->text().isEmpty()))
        return;

    static QString eow("~!@#$%^&*()_+{}|:\"<>?,./;'[]\\-="); // end of word
    const bool hasModifier = (e->modifiers() != Qt::NoModifier) && !ctrlOrShift;
    QString completionPrefix = textUnderCursor();

    if (!isShortcut && (hasModifier || e->text().isEmpty()|| completionPrefix.length() < 1
                        || eow.contains(e->text().right(1)))) {
        completer->popup()->hide();
        return;
    }

    if (completionPrefix != completer->completionPrefix()) {
        completer->setCompletionPrefix(completionPrefix);
        completer->popup()->setCurrentIndex(completer->completionModel()->index(0, 0));
    }
    QRect cr = cursorRect();
    cr.setWidth(completer->popup()->sizeHintForColumn(0)
                + completer->popup()->verticalScrollBar()->sizeHint().width() + 7);
    completer->complete(cr); // popup it up!
}

void CodeEditor::focusInEvent(QFocusEvent *e)
{
    QPlainTextEdit::focusInEvent(e);
}

void CodeEditor::resizeEvent(QResizeEvent *e)
{
    QPlainTextEdit::resizeEvent(e);
    QRect cr = contentsRect();
    lineNumberArea->setGeometry(QRect(cr.left(), cr.top(), lineNumberAreaWidth(), cr.height()));
}

void CodeEditor::highlightCurrentLine()
{
    QList<QTextEdit::ExtraSelection> extraSelections;
    QTextEdit::ExtraSelection selection;

    QColor lineColor = QColor(Qt::lightGray).lighter(130);

    selection.format.setBackground(lineColor);
    selection.format.setProperty(QTextFormat::FullWidthSelection, true);
    selection.cursor = textCursor();
    selection.cursor.clearSelection();
    extraSelections.append(selection);

    setExtraSelections(extraSelections);
}

void CodeEditor::signalToExecute()
{
    emit executionRequested();
}

void CodeEditor::signalToComment()
{
    emit commentRequested();
}

void CodeEditor::updateLineNumberAreaWidth(int)
{
    setViewportMargins(lineNumberAreaWidth(), 0, 0, 0);
}

void CodeEditor::updateLineNumberArea(const QRect &rect, int dy)
{
    if (dy)
        lineNumberArea->scroll(0, dy);
    else
        lineNumberArea->update(0, rect.y(), lineNumberArea->width(), rect.height());

    if (rect.contains(viewport()->rect()))
        updateLineNumberAreaWidth(0);
}

QStandardItemModel *CodeEditor::getModel()
{
    auto model = new QStandardItemModel(completer);
    foreach(auto file, fileContent.keys()){
        QIcon icon;
        if(file.contains("Keyword")) icon = QIcon(":/Icons/keyword.svg");
        else if(file.contains("Aggregate")) icon = QIcon(":/Icons/aggregate.svg");
        else if(file.contains("DateTime")) icon = QIcon(":/Icons/datetime.svg");
        else if(file.contains("JSON")) icon = QIcon(":/Icons/json.svg");
        else if(file.contains("Math")) icon = QIcon(":/Icons/math.svg");
        else if(file.contains("Scalar")) icon = QIcon(":/Icons/scalar.svg");
        else if(file.contains("Window")) icon = QIcon(":/Icons/window.svg");
        else if(file.contains("Type")) icon = QIcon(":/Icons/datatype.svg");

        auto lines = *(fileContent.value(file));
        foreach(auto line, lines){
            auto item = new QStandardItem(icon, line);
            item->setFont(QFont(item->font().family(), -1, QFont::Bold, false));
            item->setToolTip(file);
            model->appendRow(item);
        }
    }
    return model;
}

void CodeEditor::insertCompletion(const QString &completion)
{
    QTextCursor tc = textCursor();
    tc.movePosition(QTextCursor::PreviousCharacter, QTextCursor::KeepAnchor, completer->completionPrefix().length());
    tc.insertText(completion);
    setTextCursor(tc);
}

QString CodeEditor::textUnderCursor() const
{
    QTextCursor tc = textCursor();
    tc.select(QTextCursor::WordUnderCursor);
    return tc.selectedText();
}

void CodeEditor::dragMoveEvent(QDragMoveEvent *event)
{
    event->acceptProposedAction();
}

void CodeEditor::dragLeaveEvent(QDragLeaveEvent *event)
{
    event->accept();
}

void CodeEditor::contextMenuEvent(QContextMenuEvent *event)
{
    auto menu = createStandardContextMenu();
    menu->removeAction(menu->actions().last());
    auto executeAction = new QAction("Execute all / selected", this);
    executeAction->setEnabled(textCursor().hasSelection());
    executeAction->setShortcut(QKeySequence(Qt::Key_F5));

    auto executeComment = new QAction("Comment / Uncomment", this);
    executeComment->setEnabled(textCursor().hasSelection());
    executeComment->setShortcut(QKeyCombination(Qt::ControlModifier, Qt::Key_K));

    connect(executeAction, &QAction::triggered, this, &CodeEditor::signalToExecute);
    connect(executeComment, &QAction::triggered, this, &CodeEditor::signalToComment);

    auto first = menu->actions().first();
    menu->insertAction(first, executeAction);
    menu->insertAction(executeAction, executeComment);
    menu->insertSeparator(first);
    menu->exec(event->globalPos());
    delete menu;
}
