#ifndef ACTIONBUTTON_H
#define ACTIONBUTTON_H

#include <QSvgWidget>
#include <QObject>
#include <QDomDocument>

class ActionButton : public QSvgWidget
{
    Q_OBJECT
public:
    ActionButton(const QString &fileName, const QString toolTip, int size = 0, QWidget *parent = 0);
    bool isChecked();
    void setIsChecked(bool value);
    void setIcon(const QString&);

signals:
    void triggered();
protected:
    void enterEvent(QEnterEvent *event) override;
    void leaveEvent(QEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void changeEvent(QEvent *) override;
private:
    void changeColor(const QColor &color);
    QDomDocument m_document;
    bool m_isChecked;
};

#endif // ACTIONBUTTON_H
