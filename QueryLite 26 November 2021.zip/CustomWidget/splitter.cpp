#include "splitter.h"
#include <QGraphicsDropShadowEffect>

Splitter::Splitter(Qt::Orientation o, QWidget *p) : QSplitter(o, p){
    auto effect = new QGraphicsDropShadowEffect;
    effect->setBlurRadius(10);
    effect->setColor(Qt::black);
    effect->setOffset(0,0);
    setGraphicsEffect(effect);
}
QSplitterHandle *Splitter::createHandle(){
    auto handle = new QSplitterHandle(orientation(), this);
    handle->setPalette(QPalette(Qt::transparent));
    return handle;
}


