#ifndef OBJECTSVIEW_H
#define OBJECTSVIEW_H

#include <QObject>
#include <QTreeView>
#include <QSqlQuery>
#include "CustomWidget/roundwidget.h"

class TreeView;
class QueryWidget;

class ObjectsView : public RoundWidget
{
    Q_OBJECT
public:
    explicit ObjectsView(QWidget *parent = nullptr);

public slots:
    void onNoSelect(const QString&);

private slots:
    void openFileDialog();
    void refreshObjects();

private:
    void makeTree();
    QTreeView * tree;
    QString fileName;
    bool wasLastDDL;
};

#endif // OBJECTSVIEW_H
