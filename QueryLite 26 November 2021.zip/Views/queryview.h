#ifndef QUERYVIEW_H
#define QUERYVIEW_H

#include <QObject>
#include <QWidget>
#include "CustomWidget/roundwidget.h"
class CodeEditor;

class QueryView : public RoundWidget
{
    Q_OBJECT
public:
    explicit QueryView(QWidget *parent = nullptr);
public slots:
    void onDbChanged(QList<QString>& list);
signals:
    void queryCall(const QString& query);
private slots:
    void emitQueryCallSignal();
    void commentUncomment();
    void saveFile();

private:
    CodeEditor *editor;
};

#endif // QUERYVIEW_H
