#include "querywidget.h"
#include <QGridLayout>
#include <QTextEdit>
#include <QSplitter>
#include <QVBoxLayout>
#include <QGraphicsDropShadowEffect>
#include "Views/queryview.h"
#include "Views/objectsview.h"
#include "Views/queryresultview.h"
#include "Views/logview.h"
#include "CustomWidget/splitter.h"

QueryWidget::QueryWidget(QWidget *parent) : QWidget(parent)
{
    objects = new ObjectsView();
    codeEditor = new QueryView();
    queryresult = new QueryResultView();
    log = new LogView();

    auto split1 = new Splitter (Qt::Vertical, this);
    auto split2 = new Splitter(Qt::Horizontal, this);

    split1->addWidget(codeEditor);
    split1->addWidget(log);

    QSizePolicy objectPolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
    QSizePolicy codePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
    QSizePolicy resultPolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
    QSizePolicy logPolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
    QSizePolicy split1Policy(QSizePolicy::Preferred, QSizePolicy::Preferred);

    objectPolicy.setHorizontalStretch(1);
    codePolicy.setVerticalStretch(4);
    logPolicy.setVerticalStretch(1);
    split1Policy.setHorizontalStretch(3);
    resultPolicy.setHorizontalStretch(3);

    objects->setSizePolicy(objectPolicy);
    codeEditor->setSizePolicy(codePolicy);
    queryresult->setSizePolicy(resultPolicy);
    split1->setSizePolicy(split1Policy);
    log->setSizePolicy(logPolicy);

    split1->setGraphicsEffect(0);
    split2->addWidget(objects);
    split2->addWidget(split1);
    split2->addWidget(queryresult);

    auto vLay = new QVBoxLayout(this);
    vLay->addWidget(split2);
    connect(this, &QueryWidget::dbChanged, codeEditor, &QueryView::onDbChanged);
    connect(this, &QueryWidget::noSelect, objects, &ObjectsView::onNoSelect);
    connect(codeEditor, &QueryView::queryCall, queryresult, &QueryResultView::executeQuery);
    connect(this, &QueryWidget::logMessage, log, &LogView::onMessageReceived);
}
