#include "tableproxymodel.h"
#include <QDebug>

TableProxyModel::TableProxyModel(QObject *parent) : QSortFilterProxyModel(parent){}
void TableProxyModel::setQueries(QList<QString> queries){ this->queries = queries; }
bool TableProxyModel::filterAcceptsRow(int row, const QModelIndex&) const{
    bool match = true;
    for (int i = 0; i < sourceModel()->columnCount(); i++) {
        if(queries[i] != ""){
            if(sourceModel()->data(sourceModel()->index(row, i)).toString().toLower() == queries.at(i).toLower())
                continue;
            match = false;
            break;
        }
    }
    return match;
}
