#ifndef QUERYWIDGET_H
#define QUERYWIDGET_H

#include <QWidget>
#include <QDebug>

class QueryView;
class ObjectsView;
class QueryResultView;
class LogView;

class QueryWidget : public QWidget
{
    Q_OBJECT
public:   
    explicit QueryWidget(QWidget *parent = nullptr);
signals:
    void dbChanged(QList<QString>& list);
    void logMessage(const QString& msg);
    void noSelect(const QString& query);
private:
    QueryView *codeEditor;
    ObjectsView *objects;
    QueryResultView *queryresult;
    LogView *log;
};

#endif // QUERYWIDGET_H
