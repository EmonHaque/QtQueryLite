#include "tablewidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QTableView>
#include <QStandardItem>
#include <QHeaderView>
#include <QAbstractItemView>
#include <QIcon>
#include <QSqlError>
#include <QGraphicsDropShadowEffect>
#include "global.h"
#include "Helpers/tableheader.h"
#include "Helpers/tableitemdelegate.h"
#include "Helpers/tableproxymodel.h"

TableWidget::TableWidget(QWidget *parent) : QWidget(parent)
{
    roundWidget = new RoundWidget(this);
    roundWidget->setHeader("Tables");
    auto combo = new QComboBox(this);
    countLabel = new QLabel(this);
    countLabel->setFixedWidth(75);
    countLabel->setAlignment(Qt::AlignRight);

    auto comboView = new QTableView(combo);
    table = new QTableView(this);
    auto p = table->palette();
    p.setColor(QPalette::Base, palette().color(QPalette::Window));
    table->setPalette(p);
    tableHeader = new TableHeader(table);
    tableModel = new QSqlTableModel(table);

    table->setHorizontalHeader(tableHeader);
    table->verticalHeader()->hide();
    table->setFrameStyle(QFrame::NoFrame);
    table->setModel(tableModel);
    table->setItemDelegate(new TableItemDelegate(table));

    comboView->verticalHeader()->hide();
    comboView->horizontalHeader()->hide();
    comboView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    comboView->horizontalHeader()->setStretchLastSection(true);

    comboView->setSelectionMode(QTableView::SelectionMode::SingleSelection);
    comboView->setSelectionBehavior(QTableView::SelectionBehavior::SelectRows);
    comboView->setShowGrid(false);

    comboModel = new QStandardItemModel(comboView);
    comboModel->setColumnCount(2);
    combo->setModel(comboModel);
    combo->setView(comboView);

    combo->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred));
    roundWidget->addAction(combo, true);
    roundWidget->addAction(countLabel);
    roundWidget->addContent(table);

    auto vLay = new QVBoxLayout(this);
    vLay->addWidget(roundWidget);

    auto effect = new QGraphicsDropShadowEffect;
    effect->setBlurRadius(10);
    effect->setColor(Qt::black);
    effect->setOffset(0,0);
    setGraphicsEffect(effect);

    connect(tableHeader, &TableHeader::queryChanged, this, &TableWidget::refreshModel);
    connect(combo, &QComboBox::currentIndexChanged, this, &TableWidget::onComboSelectionChanged);
}
void TableWidget::onDbChanged(QList<QString> &list)
{
    comboModel->clear();
    foreach(auto object, list){
        if(object.startsWith("table,") || object.startsWith("view,")){
            auto splits = object.split(',');
            auto icon = splits[0] == "table" ? QIcon(":/Icons/table.svg") : QIcon(":/Icons/view.svg");
            auto col1 = new QStandardItem(icon, splits[1]);
            auto col2 = new QStandardItem(splits[0].replace(splits[0][0], splits[0][0].toUpper()));
            col2->setTextAlignment(Qt::AlignVCenter | Qt::AlignRight);
            comboModel->appendRow(QList<QStandardItem *>() << col1 << col2);
        }
    }
}
void TableWidget::onComboSelectionChanged(int index){
    tableName = comboModel->data(comboModel->index(index, 0)).toString();
    queryDatabase();
    countLabel->setText(QString::number(tableModel->rowCount()));
}
void TableWidget::onNoSelect(const QString &query){
    // track begin [transaction], end[transaction], commit, rollback
    auto upper = query.toUpper();
    bool isThisTable = query.contains(tableName);
    bool isDML = upper.contains("INSERT") || upper.contains("UPDATE") || upper.contains("DELETE");
    if(isDML && isThisTable){
        queryDatabase();
        countLabel->setText(QString::number(tableModel->rowCount()));
    }
    else if(upper.startsWith("ROLLBACK") && wasLastDML){
        queryDatabase();
        countLabel->setText(QString::number(tableModel->rowCount()));
    }
    wasLastDML = isDML && isThisTable;
}
void TableWidget::refreshModel(){
    auto queries = tableHeader->getQueries();
    QString expression;
    for (int i = 0; i < queries.size(); i++) {
        if(queries[i] == "") continue;
        auto column = tableModel->headerData(i, Qt::Horizontal).toString() + " " + queries[i] + " AND ";
        expression += column;
    }
    tableModel->setFilter(expression.left(expression.length() - 5)); // -5 to remove last " AND "
    if(tableModel->lastError().type() != QSqlError::NoError){
        tableModel->setFilter(""); // do someting else if you want
        tableModel->select();
    }
    while (tableModel->canFetchMore()) tableModel->fetchMore();
    countLabel->setText(QString::number(tableModel->rowCount()));
}
void TableWidget::queryDatabase(){
    tableModel->setTable(tableName);
    tableHeader->resetBoxes(tableModel->columnCount());
    tableModel->select();
    while (tableModel->canFetchMore()) tableModel->fetchMore();
}
