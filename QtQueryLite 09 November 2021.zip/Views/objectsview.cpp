#include "objectsview.h"
#include <QVBoxLayout>
#include <QToolBar>
#include <QAction>
#include <QIcon>
#include <QSizePolicy>
#include <QTreeView>
#include <QFileDialog>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QtSql>
#include <QMap>
#include <QList>
#include <QPair>
#include <QHeaderView>
#include <QMessageBox>
#include <QKeyEvent>
#include <QLabel>
#include "querywidget.h"
#include "CustomWidget/actionbutton.h"

QSqlDatabase db;
QSqlQuery sqlQuery;
bool isConnected;

ObjectsView::ObjectsView(QWidget *parent) : RoundWidget(parent)
{
    setHeader("Objects");
    db = QSqlDatabase::addDatabase("QSQLITE");
    isConnected = false;
    tree = new QTreeView(this);
    auto p = tree->palette();
    p.setColor(QPalette::Base, palette().color(QPalette::Window));
    tree->setPalette(p);

    tree->setHeaderHidden(true);
    tree->header()->setStretchLastSection(false);
    tree->setFrameStyle(QFrame::NoFrame);
    addContent(tree);
    auto attach = new ActionButton(":/Icons/attachDatabase.svg", "attach database");
    auto refresh = new ActionButton(":/Icons/refreshDatabase.svg", "refresh database");
    addAction(attach);
    addAction(refresh);
    connect(attach, &ActionButton::triggered, this, &ObjectsView::openFileDialog);
    connect(refresh, &ActionButton::triggered, this, &ObjectsView::refreshObjects);
}

void ObjectsView::openFileDialog(){
    QFileDialog dialog;
    if(!dialog.exec()) return;

    auto widget = static_cast<QueryWidget*>(parent()->parent());
    fileName = dialog.selectedFiles().first();
    db.setDatabaseName(fileName);
    db.open();
    sqlQuery = QSqlQuery("SELECT * FROM sqlite_master", db);
    sqlQuery.setForwardOnly(true);
    if(sqlQuery.lastError().type() != QSqlError::NoError){
        emit widget->logMessage("e," + sqlQuery.lastError().text()); //e, for error
        return;
    }
    sqlQuery.exec();
    makeTree();
    emit widget->logMessage("s,Connected to " + fileName); // s, for success
    isConnected = true;
}

void ObjectsView::refreshObjects()
{
    if(!isConnected) return;
    sqlQuery.clear();
    sqlQuery.prepare("SELECT * FROM sqlite_master");
    sqlQuery.exec();
    makeTree();
}

void ObjectsView::onNoSelect(const QString &query){
    // track begin [transaction], end[transaction], commit, rollback
    auto upper = query.toUpper().trimmed();
    bool isDDL = upper.contains("CREATE") || upper.contains("ALTER") || upper.contains("DROP");
    if(isDDL){
        sqlQuery.clear();
        sqlQuery.prepare("SELECT * FROM sqlite_master");
        sqlQuery.exec();
        makeTree();
    }
    else if(upper.startsWith("ROLLBACK") && wasLastDDL){
        sqlQuery.clear();
        sqlQuery.prepare("SELECT * FROM sqlite_master");
        sqlQuery.exec();
        makeTree();
    }
    wasLastDDL = isDDL;
}

void ObjectsView::makeTree()
{
    QStandardItemModel *model;
    QMap<QString, QStringList*> expanded;
    if(tree->model()){
        for (int row = 0; row < tree->model()->rowCount(); row++) {
            auto index = tree->model()->index(row, 0);
            if(!tree->isExpanded(index)) continue;
            auto node = tree->model()->data(index).toString();
            auto trimmed = node.left(node.indexOf(' '));
            auto list = new QStringList;
            expanded.insert(trimmed, list);
            for (int child = 0; child < tree->model()->rowCount(index); child++) {
                auto childIndex = tree->model()->index(child, 0, index);
                if(!tree->isExpanded(childIndex)) continue;
                node = tree->model()->data(childIndex).toString();
                trimmed = node.left(node.indexOf(' '));
                list->append(trimmed);
            }
        }
        tree->model()->removeRows(0, tree->model()->rowCount());
        model = qobject_cast<QStandardItemModel*>(tree->model());
    }
    else{
        model = new QStandardItemModel(tree);
        model->setColumnCount(2);
        tree->setModel(model);
        tree->header()->setSectionResizeMode(0, QHeaderView::Stretch);
    }

    QMap<QString, QList<QPair<QString, QStandardItem*>>*> map;
    QList<QString> names;

    QStandardItem *rootNode;
    QString name;
    QList<QPair<QString, QStandardItem*>> *list;

    while (sqlQuery.next()) {
        if(sqlQuery.value(0).toString() != name){
            name = sqlQuery.value(0).toString();
            list = new QList<QPair<QString, QStandardItem*>>;
            map.insert(name, list);
            QIcon icon;
            if(name == "table") icon = QIcon(":/Icons/table.svg");
            else if(name == "view") icon = QIcon(":/Icons/view.svg");
            else if(name == "trigger") icon = QIcon(":/Icons/trigger.svg");
            else icon = QIcon(":/Icons/index.svg");
            rootNode = new QStandardItem(icon, name);
            rootNode->setFont(QFont(rootNode->font().family(), -1, QFont::Bold, false));
            model->appendRow(rootNode);
        }
        auto text = sqlQuery.value(1).toString();
        if(name == "trigger") names.append("trigger," + text);
        auto child = new QStandardItem(text);
        rootNode->appendRow(child);
        QPair<QString, QStandardItem*> pair;
        pair.first = text;
        pair.second = child;
        map.value(name)->append(pair);
    }

    foreach(QString key, map.keys()){
        if(key == "index"){
            sqlQuery.clear();
            auto list = map.value(key);
            foreach(auto table, *list){
                if(!names.contains("index," + table.first)) names.append("index," + table.first);
                sqlQuery.prepare("PRAGMA index_info(" + table.first + ")");
                sqlQuery.exec();
                while (sqlQuery.next()) {
                    auto child = new QStandardItem(sqlQuery.value(2).toString());
                    table.second->appendRow(child);
                }
            }
            list->first().second->parent()->setText("Index (" + QString::number(list->size()) + ")");
        }
        else if( key == "table"){
            sqlQuery.clear();
            auto list = map.value(key);
            foreach(auto table, *list){
                if(!names.contains("table," + table.first)) names.append("table," + table.first);
                sqlQuery.prepare("PRAGMA table_info(" + table.first + ")");
                sqlQuery.exec();
                int columnCount = 0;
                while (sqlQuery.next()) {
                    auto columnName = sqlQuery.value(1).toString();
                    if(!names.contains("column," + columnName)) names.append("column," + columnName);
                    auto child1 = new QStandardItem(columnName);
                    auto child2 = new QStandardItem(sqlQuery.value(2).toString());
                    table.second->appendRow(QList<QStandardItem *>() << child1 << child2);
                    columnCount++;
                }
                table.second->setText(table.first + " (" + QString::number(columnCount) + ")");
            }
            list->first().second->parent()->setText("Table (" + QString::number(list->size()) + ")");
        }
        else if(key == "view"){
            sqlQuery.clear();
            auto list = map.value(key);
            foreach(auto table, *list){
                if(!names.contains("view," + table.first)) names.append("view," + table.first);
                sqlQuery.prepare("PRAGMA table_info(" + table.first + ")");
                sqlQuery.exec();
                int columnCount = 0;
                while (sqlQuery.next()) {
                    auto columnName = sqlQuery.value(1).toString();
                    if(!names.contains("column," + columnName)) names.append("column," + columnName);
                    auto child1 = new QStandardItem(columnName);
                    auto child2 = new QStandardItem(sqlQuery.value(2).toString());
                    table.second->appendRow(QList<QStandardItem *>() << child1 << child2);
                    columnCount++;
                }
                table.second->setText(table.first + " (" + QString::number(columnCount) + ")");
            }
            list->first().second->parent()->setText("View (" + QString::number(list->size()) + ")");
        }
        else{
            auto list = map.value(key);
            list->first().second->parent()->setText("Trigger (" + QString::number(list->size()) + ")");
        }
    }

    auto *widget = static_cast<QueryWidget*>(parent()->parent());
    emit widget->dbChanged(names);
    qDeleteAll(map);

    for (int row = 0; row < tree->model()->rowCount(); row++) {
        auto index = tree->model()->index(row, 0);
        auto node = tree->model()->data(index).toString();
        auto trimmed = node.left(node.indexOf(' '));
        if(!expanded.keys().contains(trimmed)) continue;
        tree->setExpanded(index, true);
        if(expanded.value(trimmed)->size()){
            auto list = expanded.value(trimmed);
            for (int child = 0; child < tree->model()->rowCount(index); child++) {
                auto childIndex = tree->model()->index(child, 0, index);
                node = tree->model()->data(childIndex).toString();
                trimmed = node.left(node.indexOf(' '));
                if(list->contains(trimmed)) tree->setExpanded(childIndex, true);
            }
        }
    }
    qDeleteAll(expanded.values());
}
