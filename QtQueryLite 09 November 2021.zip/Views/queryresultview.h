#ifndef QUERYRESULTVIEW_H
#define QUERYRESULTVIEW_H

#include <QObject>
#include <QWidget>
#include <QTableView>
#include <QtSql>
#include "CustomWidget/roundwidget.h"

class QueryWidget;
class ActionButton;
class QueryResultView : public RoundWidget
{
    Q_OBJECT
public:
    explicit QueryResultView(QWidget *parent = nullptr);

protected:
    void keyPressEvent(QKeyEvent *event) override;

public slots:
    void executeQuery(const QString& query);
    void copyTable();
    void printTable();

private:
    QTableView * table;
    QSqlQueryModel * resultModel;
    QElapsedTimer timer;
    QString query;
    ActionButton *copy, *print;
};

#endif // QUERYRESULTVIEW_H
