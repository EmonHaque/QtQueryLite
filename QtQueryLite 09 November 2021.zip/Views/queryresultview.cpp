#include "queryresultview.h"
#include <QVBoxLayout>
#include <QElapsedTimer>
#include <QLabel>
#include <QToolBar>
#include <QGuiApplication>
#include <QClipboard>
#include <QTextDocument>
#include <QTextCursor>
#include <QPrinter>
#include <QPageSize>
#include <QTextTable>
#include <QHeaderView>
#include "global.h"
#include "Helpers/tableitemdelegate.h"
#include "querywidget.h"
#include "CustomWidget/actionbutton.h"

QueryResultView::QueryResultView(QWidget *parent) : RoundWidget(parent)
{    
    setHeader("Result");
    table = new QTableView(this);
    auto p = table->palette();
    p.setColor(QPalette::Base, palette().color(QPalette::Window));
    table->setPalette(p);

    resultModel = new QSqlQueryModel(this);
    table->setModel(resultModel);
    table->setItemDelegate(new TableItemDelegate(table));
    table->verticalHeader()->hide();
    table->setFrameStyle(QFrame::NoFrame);
    addContent(table);

    copy = new ActionButton(":/Icons/copy.svg", "Copy");
    print = new ActionButton(":/Icons/print.svg", "Print (permanently disabled)");
    print->setEnabled(false);
    addAction(copy);
    addAction(print);

    connect(copy, &ActionButton::triggered, this, &QueryResultView::copyTable);
    connect(print, &ActionButton::triggered, this, &QueryResultView::printTable);
}

void QueryResultView::keyPressEvent(QKeyEvent *event)
{
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_C){
        if(!table->model()->hasChildren()) return;
        copyTable();
    }
}

void QueryResultView::executeQuery(const QString &query){

    auto widget = static_cast<QueryWidget*>(parent()->parent());
    if(!isConnected){
        emit widget->logMessage("e,Not Connected to a database");
        return;
    }
    timer.start();
    this->query = query;
    auto statements = query.split(';', Qt::SkipEmptyParts);

    if(statements.size() == 1) {
        resultModel->setQuery(query);
        if(resultModel->query().lastError().type() != QSqlError::NoError){
            emit widget->logMessage("e," + resultModel->query().lastError().text());
            return;
        }
        if(resultModel->query().isSelect()){
            while (resultModel->canFetchMore()) resultModel->fetchMore();
            emit widget->logMessage("s,Execution finished in " + QString::number(timer.elapsed()) + " ms. Returned " + QString::number(resultModel->rowCount()) + " row(s)");
        }
        else{
            emit widget->logMessage("s,Execution finished in " + QString::number(timer.elapsed()) + " ms.");
            emit widget->noSelect(query);
        }
    }
    else{
        bool gotError = false;
        for (int i = 0; i < statements.size(); i++) {
            auto trimmed = statements[i].trimmed();
            if(trimmed.startsWith("--")) continue;
            if(trimmed.toUpper().startsWith("PRAGMA")){
                emit widget->logMessage("e,PRAGMA isn't allowed while executing multiple statements");
                gotError = true;
                break;
            }
            sqlQuery.clear();
            sqlQuery.prepare(trimmed);
            if(sqlQuery.isSelect()){
                emit widget->logMessage("e,SELECT isn't allowed while executing multiple statements");
                gotError = true;
                break;
            }
            else if(sqlQuery.lastError().type() != QSqlError::NoError){
                emit widget->logMessage("e," + sqlQuery.lastError().text());
                gotError = true;
                break;
            }
            sqlQuery.exec();
        }
        if(gotError) return;
        emit widget->logMessage("s,Execution finished in " + QString::number(timer.elapsed()) + " ms");
        emit widget->noSelect(query);
    }
}

void QueryResultView::copyTable()
{
    if(!table->model()->hasChildren()) return;
    if(!table->selectionModel()->hasSelection())
        table->selectAll();
    QString text;
    auto indexes = table->selectionModel()->selectedIndexes();
    auto previous = indexes.first();
    foreach(auto current, indexes){
        if (current.row() != previous.row())
            text.append('\n' + table->model()->data(current).toString() + '\t');
        else text.append(table->model()->data(current).toString() + '\t');
        previous = current;
    }
    QGuiApplication::clipboard()->setText(text);
}

void QueryResultView::printTable()
{
    int row = table->model()->rowCount();
    int column = table->model()->columnCount();
    QPrinter printer;
    printer.setPageSize(QPageSize::A4);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName("test.pdf");
    QTextDocument doc;
    QTextCursor cursor(&doc);
    QTextTableFormat tableFormat;
    tableFormat.setBorderCollapse(true);
    tableFormat.setHeaderRowCount(row);
    cursor.insertTable(row, column);
    for (int r = 0; r < row; r++) {
        for (int c = 0; c < column; c++) {
            auto index = table->model()->index(r, c);
            cursor.insertText( table->model()->data(index).toString() );
            cursor.movePosition(QTextCursor::NextCell);
        }

    }
    doc.print(&printer);
}


