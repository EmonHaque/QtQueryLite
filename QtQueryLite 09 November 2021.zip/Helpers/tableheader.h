#ifndef TABLEHEADER_H
#define TABLEHEADER_H

#include <QHeaderView>
#include <QObject>
#include <QTableView>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QList>
#include <QLabel>

class TableHeader : public QHeaderView
{
    Q_OBJECT
public:
    TableHeader(QTableView * parent = 0);
    ~TableHeader();
    QSize sizeHint() const override;
    QList<QString>& getQueries();
    void resetBoxes(int count);
protected:
    bool eventFilter(QObject *obj, QEvent *ev) override;
    void paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const override;
signals:
    void queryChanged();
protected slots:
    void updateGeometries() override;
    void updatePosition();
    void textChanged();
private:
    QList<QLineEdit*> lineEdits;
    QList<QString> queries;

    // QWidget interface
protected:
    //void paintEvent(QPaintEvent *event) override;
};
#endif // TABLEHEADER_H
