#include "tableitemdelegate.h"

TableItemDelegate::TableItemDelegate(QObject *parent) : QStyledItemDelegate(parent)
{

}

void TableItemDelegate::initStyleOption(QStyleOptionViewItem *option, const QModelIndex &index) const
{
    QStyledItemDelegate::initStyleOption(option, index);
    auto value = index.data(Qt::DisplayRole);
    if (value.isNull()){
        option->features |= QStyleOptionViewItem::HasDisplay;
        option->text = "NULL";
        option->palette.setBrush(QPalette::Text, QBrush(Qt::gray));
        option->font = QFont(option->font.family(), -1, -1, true);
    }
}
