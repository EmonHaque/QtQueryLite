#ifndef TABLEPROXYMODEL_H
#define TABLEPROXYMODEL_H

#include <QSortFilterProxyModel>
#include <QObject>
#include <QList>

class TableProxyModel : public QSortFilterProxyModel
{
    Q_OBJECT
public:
    explicit TableProxyModel(QObject *parent = nullptr);
    void setQueries(QList<QString> queries);

protected:
    bool filterAcceptsRow(int source_row, const QModelIndex &source_parent) const override;

private:
    QList<QString> queries;
};

#endif // TABLEPROXYMODEL_H
