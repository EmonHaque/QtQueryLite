#ifndef FOULEDIT_H
#define FOULEDIT_H

#include <QWidget>
#include <QPlainTextEdit>
#include <QObject>
#include <QWheelEvent>
#include <QDebug>
#include <QCompleter>
#include <QAbstractItemModel>
#include <QStandardItemModel>
#include <QFile>
#include <QStringList>
#include <QStringListModel>
#include <QByteArray>
#include <QAbstractItemView>
#include <QScrollBar>
#include <QPainter>
#include <QTextBlock>
#include <QList>
#include "CustomWidget/highlighter.h"
class LineNumberArea;

class CodeEditor : public QPlainTextEdit
{
    Q_OBJECT

public:
    CodeEditor(QWidget * parent = nullptr);
    QStandardItemModel * getCompleterModel();
    Highlighter *getHighlighter();
    void lineNumberAreaPaintEvent(QPaintEvent *event);
    int lineNumberAreaWidth();
protected:
    void keyPressEvent(QKeyEvent *e) override;
    void focusInEvent(QFocusEvent *e) override;
    void resizeEvent(QResizeEvent *e) override;
    void wheelEvent(QWheelEvent *e) override;
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dropEvent(QDropEvent *event) override;
    void dragMoveEvent(QDragMoveEvent *event) override;
    void dragLeaveEvent(QDragLeaveEvent *event) override;
    void contextMenuEvent(QContextMenuEvent *event) override;
private slots:
    void highlightCurrentLine();
    void signalToExecute();
    void signalToComment();
    void updateLineNumberAreaWidth(int newBlockCount);
    void updateLineNumberArea(const QRect &rect, int dy);
signals:
    void executionRequested();
    void commentRequested();
private:
    QStandardItemModel *getModel();
    void insertCompletion(const QString &completion);
    QString textUnderCursor() const;
    QStandardItemModel *completerModel;
    QCompleter *completer;
    LineNumberArea *lineNumberArea;
    Highlighter *highlighter;
    friend class LineNumberArea;
};

#endif // FOULEDIT_H
