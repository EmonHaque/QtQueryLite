#ifndef WINDOW_H
#define WINDOW_H

#include <QObject>
#include <QWidget>
#include <QStackedWidget>
#include <QVBoxLayout>

class ActionButton;
class Window : public QWidget
{
    Q_OBJECT
public:
    explicit Window(QWidget *parent = nullptr);

protected:
    void mouseMoveEvent(QMouseEvent *) override;
    void mousePressEvent(QMouseEvent *) override;
    void paintEvent(QPaintEvent *) override;
private:
    void resetCentralWidget();
    void maximizeRestore();
    QPoint dragPosition;
    ActionButton * maximize;
    QStackedWidget * stack;
    int radius;
    QVBoxLayout * leftBar;
};

#endif // WINDOW_H
